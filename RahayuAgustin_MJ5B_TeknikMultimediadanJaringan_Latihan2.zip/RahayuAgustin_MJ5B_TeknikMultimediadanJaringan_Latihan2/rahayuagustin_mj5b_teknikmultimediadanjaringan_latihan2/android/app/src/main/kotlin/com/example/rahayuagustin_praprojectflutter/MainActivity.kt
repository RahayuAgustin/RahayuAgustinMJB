package com.example.rahayuagustin_praprojectflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
